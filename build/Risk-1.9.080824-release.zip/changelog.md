Changelog 

## v.1.9

- Add Ignore Apps Like systemui etc.
- Enter New Line Install.sh
- Added excluded_apps.txt in /sdcard/Android/Risk

## v.1.8

- Bump Version 1.6 to 1.8
- Fix Read Case 