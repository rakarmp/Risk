Changelog 

## v.2.0

- Fix For ROM Not Support Using Shizuku (HOTFIX)
- Implement rish Shizuku for ROM Not Support
- Add LMKD, LMK Adjusment

## v.1.9

- Add Ignore Apps Like systemui etc.
- Enter New Line Install.sh
- Added excluded_apps.txt in /sdcard/Android/Risk
- Added Ignore jackpal.androidterm

## v.1.8

- Bump Version 1.6 to 1.8
- Fix Read Case 