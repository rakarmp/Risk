# Risk

Is a Magisk Module for Clean RAM Cache And Stop Background Apps, Google Apps, Third Party Apps Before Playing Games, To Get More Free RAM

## Preview

![screenshot](https://raw.githubusercontent.com/rakarmp/Risk/main/screenshot/img.jpg)

## Links

Go to [here](https://t.me/rexxCloud/1178) to downloads Risk™