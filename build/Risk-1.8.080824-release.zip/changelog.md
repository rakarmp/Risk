Changelog 

## v.1.8

- Bump Version 1.6 to 1.8
- Fix Read Case 